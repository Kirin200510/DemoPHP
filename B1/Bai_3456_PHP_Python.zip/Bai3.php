<?php
function myReverse(string $s): string {
    $result=preg_match_all('/\X/u', $s, $matches);
    $result = $matches[0];
    $reversed = implode('', array_reverse($result));
    return $reversed;
}
function palindrome($sentence):bool {
    $sentence=trim($sentence);
    $sentence=preg_replace('/\s+/u', '', $sentence);
    if ($sentence === '') {
        return false; 
    }
    $reversedSentence=null;
    $reversedSentence=strtolower(myReverse($sentence));
    return strtolower($sentence) === $reversedSentence;
}
echo("Nhập câu: ");
$sentence = readline();
if(palindrome($sentence)){
    echo "Câu vừa nhập là câu Palindrome\n";
}else{
    echo "Câu vừa nhập không phải là câu Palindrome\n";
}
?>